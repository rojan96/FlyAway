<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FlyAway</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-flat.css">
    <link href="https://fonts.googleapis.com/css?family=Yatra+One" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<div class="home"></div>
<body style="font-family: 'Yatra One'; background-color: #161b21">

<!--NAVIGATION BAR CODE-->
    <nav class="navbar navbar-expand-sm navbar-light bg-light " >
        <a class="navbar-brand" href="#home" style="color:#161b21 ">FlyAway</a>
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId"
                aria-controls="collapsibleNavId"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php" style="color:#161b21 ">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#destination" style="color:#161b21 ">Destinations</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#About" style="color:#161b21 ">About</a>
                </li>

                <?php
                    if (isset($_SESSION['Username']))
                    {
                        echo ' <div class="nav-item "> <a class="nav-link" href="useraccount.php" style="color#161b21">Account</a></div>';
                        echo ' <div class="nav-item "> <a class="nav-link" href="dashboard.php" style="color#161b21">Dashboard</a></div>';
                        echo ' <div class="nav-item "> <a class="nav-link" href="logout.php" style="color#161b21">Log out</a></div>';

                    }
                    else
                    {
                        echo ' <div class="nav-item "> <a class="nav-link" href="Signup.php" style="color#161b21">Sign up or Log in</a></div>';
                    }
                ?>

            </ul>
        </div>
    </nav>



<!--Jumbotron code-->
    <div class="jumbotron" style="    background-position: right; padding: 5%;
    color:#F4A950; background-image: url('images/jumbotron_main.jpg'); background-repeat: no-repeat; background-size: auto 100%; background-color: #161b21;">
        <h1 class="display-3" >FlyAway!</h1>
       <h2>
            <?php
           // include 'connection.php'
            if (isset($_SESSION['Username'])) {
                echo 'Hello, '.$_SESSION['Username'];
            }
            else {
                echo 'Book your dream holiday now!';
            }
            ?>

       </h2>
       <?php
            if (isset($_SESSION['Username'])){
                echo '<hr class="my-2"><p class="lead"><a class="btn btn-primary btn-lg" href="bookings.php" role="button">Book your dream holiday now!</a></p>';
            }

            else{
                echo '<hr class="my-2"><p class="lead"><a class="btn btn-primary btn-lg" href="Signup.php" role="button">Sign up or log in!</a></p>';
            }
       ?>
    </div>

<!--Carousel Code-->
<!--<div class="container">-->
    <div class="row" >
        <div class="col-md-1"></div>
        <div id="carouselId" class="carousel slide col-md-12 col-sm-12" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselId" data-slide-to="0" class="active"></li>
                <li data-target="#carouselId" data-slide-to="1"></li>
                <li data-target="#carouselId" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                    <img src="carousel_1.jpg" style="width: 100%" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img src="carousel_2.jpg" style="width: 100%" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img src="carousel_3.jpg" style="width: 100%" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselId" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselId" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <div class="col-md-1"></div>
    </div>
<!--</div>-->


<!--About code-->
<div id="About" style="padding-top: 5%"></div>
<div class="container">
    <div class="jumbotron">
        <h2 class="display-3" style="text-align: center;background-color: #F4A950 ">What is FlyAway?</h2>
        <p class="lead">We are your #1 website to book your dream holiday. Get the cheapest tickets to the best destinations. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse elementum maximus elit ut tempor. Proin dapibus commodo tellus. Phasellus vel nisl vestibulum nunc imperdiet eleifend a nec massa. Proin ut nisi nisl. Quisque vel urna blandit, tempus nulla in, imperdiet augue. Integer pharetra, ex at pellentesque convallis, justo urna commodo ipsum, ut egestas libero ipsum in nunc. Maecenas sit amet pharetra enim, ac feugiat sapien. Sed nec eros commodo, bibendum libero sed, eleifend orci. Cras nec libero pharetra, vulputate mauris sit amet, feugiat lectus. Mauris sed elementum elit, quis feugiat nulla. Quisque maximus nisl eu erat ornare, id consequat tellus sollicitudin.</h2>
        </p>
    </div>
</div>

<!--Our Destinations code-->
    <div class="row" id="destination" style="padding: 50px">
        <div class=" col-sm-12 col-md-6 col-lg-3 card" >
            <div class="card-body">
                <img class="card-img-bottom" src="images/np.jpg" alt="Card image" style="width:100%">
                <h4 class="card-title">Nepal</h4>
                <p class="card-text">Some example text some example text.</p>
                <a href="#" class="btn btn-primary">See Flights to Nepal</a>
            </div>
        </div>

        <div class="col-sm-12col-md-6 col-lg-3 card" >
            <div class="card-body">
                <img class="card-img-bottom" src="images/Fr.png" alt="Card image" style="width:100%">
                <h4 class="card-title">France</h4>
                <p class="card-text">Some example text some example text.</p>
                <a href="#" class="btn btn-primary">See Flights to France</a>
            </div>
        </div>

        <div class="col-sm-12 col-md-6 col-lg-3 card" >
            <div class="card-body">
                <img class="card-img-bottom" src="images/Af.jpg" alt="Card image" style="width:100%">
                <h4 class="card-title">Africa</h4>
                <p class="card-text">Some example text some example text.</p>
                <a href="#" class="btn btn-primary">See Flights to Africa</a>
            </div>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-3 card" >
            <div class="card-body">
                <img class="card-img-bottom" src="images/jp.jpg" alt="Card image" style="width:100%">
                <h4 class="card-title">Japan</h4>
                <p class="card-text">Some example text some example text.</p>
                <a href="#" class="btn btn-primary">See Flights to Japan</a>
            </div>
        </div>
    </div>

<!--Contact Us Section-->

<div id="Contact"></div>
        <div class="jumbotron" style="background-color: #161b21 ">
            <h4 class="display-4" style="color:#F4A950; text-align: center">Contact Us</h4>
            <p style="color:gray; text-align: center; color:whitwe" class="link"> <a href="https://www.fb.com">Facebook</a></p>
            <p style="color:gray; text-align: center;color:#F4A950" class="link"> <a href="https://www.instagram.com"> Instagram </a></p>
            <h5 style="text-align: center; color:white;">2019 ©  Fly Away, Inc. All rights reserved.</h5>


    </div>

</body>
</html>